#include <iostream>
#include <stdlib.h>
#include <sys/time.h>
#include <pthread.h>
#include <errno.h>
#include <time.h>
#include <string>
#include <fstream>
#include <vector>
#include <math.h>

/*
	Adam Gincel - agincel
	hw2.c

	I pledge my honor that I have abided by the Stevens Honor System.
*/

#define MEMORY_LOCATIONS 512

using namespace std;
int pageID = 0, accessOperations = 0, pageFaults;

class Page //create Page class
{
	public:
		int name;
		bool validBit;
		int timeLastAccessed;
		int R; //R bit for clock

		Page();
		void setBit(bool x);
		bool clockCheck(); //clock check calls setBit(false) if R == 0, otherwise sets R = 0
	private:
};

vector<Page *> pages;

Page::Page()
{
	name = pageID++;
	validBit = false;
	timeLastAccessed = -1;
}

void Page::setBit(bool x)
{
	validBit = x;
	timeLastAccessed = accessOperations++;
	R = x ? 1 : 0;
}


bool Page::clockCheck()
{
	if(R == 1)
	{
		R = 0;
		return false;
	}
	else //R == 0
	{
		setBit(false);
		return true;
	}
}






int main(int argc, char** argv)
{
	if (argc != 6) //wrong usage
	{
		cout << "usage: ./hw2 plist ptrace pageSize algorithm +/-\n";
		return 1;
	}

	int pageSize = atoi(argv[3]), numberOfPrograms = 0, readInt; //declare variables
	string algorithm = argv[4];
	bool prePagingFlag = false;
	if(argv[5][0] == '+')
		prePagingFlag = true;

	ifstream plist, ptrace;
	string lineOfFile;
	plist.open(argv[1]); //give it the file plist
	if(!plist)
	{
		cout << "Invalid plist file.\n";
		return 1;
	}
	while(getline(plist, lineOfFile) && plist.is_open()) //find number of programs
		numberOfPrograms++;
	plist.clear();
	plist.seekg(0, plist.beg); //back to beginning of plist

	vector<int> pagesNeeded;
	pagesNeeded.resize(numberOfPrograms);
	//cout << "LOADING PAGES NEEDED" << endl;
	while(!plist.eof() && plist.is_open()) //load needed pages by program ID
	{
		plist >> readInt;
		if (readInt >= 0 && readInt < numberOfPrograms)
			plist >> pagesNeeded[readInt];
	}

	int pagesPerFile = MEMORY_LOCATIONS / (pageSize * numberOfPrograms);

	vector<Page*> pages[numberOfPrograms]; //array of vector of Page* (array index corresponds to programID, vectors are for variable amount of pages per program)
	for(int i = 0; i < numberOfPrograms; i++) //give all programs pages
	{
		pages[i].resize(ceil(pagesNeeded[i] / pageSize) + 1);
		for(int j = 0; j < pages[i].size(); j++)
		{
			pages[i][j] = new Page();
			if(j < pagesPerFile && j < pages[i].size())
			{
				pages[i][j]->setBit(true);
			}
		}
	}

	//read in from ptrace (form [programID] [memory_address_to_access])
	//if memory address (actually page, divide desired address by pageSize to get corresponding page) is valid, OK
	//if invalid, invalidate x pages via algorithms and validate current page

	//cout << "..Done\nTime to load from ptrace";
	ptrace.open(argv[2]);
	if(!ptrace)
	{
		cout << "Invalid ptrace file\n";
		return 1;
	}
	int program, memAddr, pageWanted, oldestTime, oldestTimeIndex;
	int clockHands[numberOfPrograms];
	for(int i = 0; i < numberOfPrograms; i++)
		clockHands[i] = 0;
	while(!ptrace.eof() && ptrace.is_open())
	{
		ptrace >> program;
		if(program >= 0 && program < numberOfPrograms)
		{
			ptrace >> memAddr;
			pageWanted = memAddr / pageSize;
			if(algorithm.compare("LRU") == 0) //if LRU, update timeLastAccessed every time, not just when added into memory
				pages[program][pageWanted]->timeLastAccessed = accessOperations++;
			if(pages[program][pageWanted]->validBit)
			{
				pages[program][pageWanted]->R = 1; //set R to true when accessed (make "clean")
			}
			else //set one to false or to true by algorithm
			{
				if(algorithm.compare("FIFO") == 0) //first in, first out algorithm
				{
					pageFaults++;
					oldestTime = -1;
					oldestTimeIndex = -1;
					for(int i = 0; i < pages[program].size(); i++) //find oldest loaded Page
					{
						if(pages[program][i]->validBit && (pages[program][i]->timeLastAccessed < oldestTime || oldestTime == -1))
						{
							oldestTime = pages[program][i]->timeLastAccessed;
							oldestTimeIndex = i;
						}
					}
					if(oldestTime != -1 && oldestTimeIndex != -1)
						pages[program][oldestTimeIndex]->setBit(false);
					pages[program][pageWanted]->setBit(true);
					if(prePagingFlag && pageWanted < pages[program].size() - 1) //do it again for prepaging
					{
						oldestTime = -1;
						oldestTimeIndex = -1;
						for(int i = 0; i < pages[program].size(); i++)
						{
							if(pages[program][i]->validBit && (pages[program][i]->timeLastAccessed < oldestTime || oldestTime == -1))
							{
								oldestTime = pages[program][i]->timeLastAccessed;
								oldestTimeIndex = i;
							}
						}
						if(oldestTime != -1 && oldestTimeIndex != -1 && oldestTimeIndex != pageWanted)
							pages[program][oldestTimeIndex]->setBit(false);
						while(pageWanted < pages[program].size() && pages[program][pageWanted]->validBit)
							pageWanted++;
						if(pageWanted < pages[program].size()) //initial load
						{
							pages[program][pageWanted]->setBit(true);
							pageFaults++;
						}
					}
				}
				else if(algorithm.compare("LRU") == 0) //Least Recently Used algorithm
				{
					pageFaults++;
					oldestTime = -1;
					oldestTimeIndex = -1;
					for(int i = 0; i < pages[program].size(); i++) //find least recently used valid page
					{
						if(pages[program][i]->validBit && (pages[program][i]->timeLastAccessed < oldestTime || oldestTime == -1))
						{
							oldestTime = pages[program][i]->timeLastAccessed;
							oldestTimeIndex = i;
						}
					}
					if(oldestTime != -1 && oldestTimeIndex != -1)
						pages[program][oldestTimeIndex]->validBit = false;
					pages[program][pageWanted]->validBit = true;

					if(prePagingFlag && pageWanted < pages[program].size() - 1) //Prepaging for LRU, might be broken but I can't figure out why
					{
						oldestTime = -1;
						oldestTimeIndex = -1;
						for(int i = 0; i < pages[program].size(); i++)
						{
							if(pages[program][i]->validBit && (pages[program][i]->timeLastAccessed < oldestTime || oldestTime == -1))
							{
								oldestTime = pages[program][i]->timeLastAccessed;
								oldestTimeIndex = i;
							}
						}
						if(oldestTime != -1 && oldestTimeIndex != -1 && oldestTimeIndex != pageWanted)
							pages[program][oldestTimeIndex]->validBit = false;
						while(pageWanted < pages[program].size() && pages[program][pageWanted]->validBit)
							pageWanted++;
						if(pageWanted < pages[program].size())
							pages[program][pageWanted]->validBit = true;
					}
				}
				else if(algorithm.compare("Clock") == 0) //Clock algorithm
				{
					pageFaults++;
					//find first valid page
					while(!pages[program][clockHands[program]]->validBit)
					{
						clockHands[program] = (clockHands[program] + 1) % pages[program].size();
					}
					while(!pages[program][clockHands[program]]->validBit || (pages[program][clockHands[program]]->validBit && !pages[program][clockHands[program]]->clockCheck()))
						clockHands[program] = (clockHands[program] + 1) % pages[program].size();
					clockHands[program] = (clockHands[program] + 1) % pages[program].size();
					pages[program][pageWanted]->setBit(true);
					if(prePagingFlag && pageWanted < pages[program].size() - 1)
					{
						while(!pages[program][clockHands[program]]->validBit || (pages[program][clockHands[program]]->validBit && !pages[program][clockHands[program]]->clockCheck()))
							clockHands[program] = (clockHands[program] + 1) % pages[program].size();
						clockHands[program] = (clockHands[program] + 1) % pages[program].size();
						while(pageWanted < pages[program].size() && pages[program][pageWanted]->validBit)
							pageWanted++;
						if(pageWanted < pages[program].size())
							pages[program][pageWanted]->validBit = true;
					}
				}
			}
		}
	}
	cout << "Total page faults: " << pageFaults << endl;
	return 0;
}
