#include "MySBBST.hh"
/*
Adam Gincel
MySBBST.cpp
This file contains the implementations for the AVL Tree.

I pledge my honor that I have abided by the Stevens Honor System.
*/

bool intintCompare::lt(int x, int y)
{
  return x < y;
}

bool intintCompare::gt(int x, int y)
{
	return x > y;
}

bool intintCompare::eq(int x, int y)
{
	return x == y;
}